i=20
while [ $i -gt 5 ]
do
    echo "value of i = $i"
    ((i=i-5))
done



