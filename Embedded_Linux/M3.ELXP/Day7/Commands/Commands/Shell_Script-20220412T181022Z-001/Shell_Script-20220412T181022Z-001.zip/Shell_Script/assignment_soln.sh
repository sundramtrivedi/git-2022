#!/bin/bash
read -p "Enter the command : " command 
echo $command 
echo `$command`